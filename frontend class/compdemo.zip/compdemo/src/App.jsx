import ParentComp from "./components/ParentComp";

function App() {
  return (
    <div>
      <ParentComp />
    </div>
  );
}

export default App;