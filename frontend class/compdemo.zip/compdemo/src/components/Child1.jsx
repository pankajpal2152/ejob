import Child2 from "./Child2";

function Child1({ sendToParent }) {
  return (
    <div>
      <h3>Child1 Component</h3>
      <Child2 sendToParent={sendToParent} />
    </div>
  );
}

export default Child1;