function Child2({ sendToParent }) {

  const userData = { id: 1, name: "John" };

  return (
    <div>
      <h4>Child2 Component</h4>

      <button onClick={() => sendToParent(userData)}>
        Send Data to Parent
      </button>

    </div>
  );
}

export default Child2;