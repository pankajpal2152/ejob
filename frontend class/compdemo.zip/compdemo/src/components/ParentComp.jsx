import { useState } from "react";
import Child1 from "./Child1";

function ParentComp() {
  const [user, setUser] = useState(null);

  // Function to receive data from Child2
  const receiveData = (data) => {
    console.log("Data received in Parent:", data);
    setUser(data);
  };

  return (
    <div>
      <h2>Parent Component</h2>

      <Child1 sendToParent={receiveData} />

      {user && (
        <div>
          <h3>Received Data:</h3>
          <p>ID: {user.id}</p>
          <p>Name: {user.name}</p>
        </div>
      )}
    </div>
  );
}

export default ParentComp;