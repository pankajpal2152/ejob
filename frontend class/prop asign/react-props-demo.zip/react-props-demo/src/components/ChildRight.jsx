function ChildRight({ msg }) {
    return (
        <div style={{ border: "2px solid green", padding: "10px", margin: "10px" }}>
            <h3>Child Right</h3>
            <p>{msg}</p>
        </div>
    );
}

export default ChildRight;