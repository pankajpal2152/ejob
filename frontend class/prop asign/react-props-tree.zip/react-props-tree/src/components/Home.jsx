function Home({ msg }) {
    return (
        <div style={{ border: "2px solid green", padding: "10px", margin: "10px" }}>
            <h2>Home</h2>
            <p>{msg}</p>
        </div>
    );
}

export default Home;